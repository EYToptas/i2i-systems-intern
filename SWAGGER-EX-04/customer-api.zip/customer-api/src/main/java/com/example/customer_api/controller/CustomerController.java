package com.example.customer_api.controller;

import com.example.customer_api.dto.CustomerDTO;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/customers")
public class CustomerController {

    private final Map<Long, CustomerDTO> db = new HashMap<>();

    @PostMapping
    public ResponseEntity<CustomerDTO> create(@RequestBody CustomerDTO customer) {
        db.put(customer.getId(), customer);
        return new ResponseEntity<>(customer, HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<CustomerDTO> get(@PathVariable Long id) {
        CustomerDTO customer = db.get(id);
        if (customer != null) {
            return ResponseEntity.ok(customer);
        }
        return ResponseEntity.notFound().build();
    }

    @GetMapping
    public ResponseEntity<List<CustomerDTO>> getAll() {
        return ResponseEntity.ok(new ArrayList<>(db.values()));
    }

    @PutMapping("/{id}")
    public ResponseEntity<CustomerDTO> update(@PathVariable Long id, @RequestBody CustomerDTO updatedCustomer) {
        if (!db.containsKey(id)) {
            return ResponseEntity.notFound().build();
        }
        updatedCustomer.setId(id); // ID sabit kalsın
        db.put(id, updatedCustomer);
        return ResponseEntity.ok(updatedCustomer);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        if (db.remove(id) != null) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }
}
